# Read a File and Handle Errors with Styled Output

from colorama import init, Fore, Style

# Initialize colorama
init(autoreset=True)

try:
    print(Fore.MAGENTA + "Reading file content:")
    with open("sample.txt", "r") as file:
        for i, line in enumerate(file, start=1):
            print(Fore.RED + f"Line {i}:" + Fore.CYAN + f" {line.strip()}")
except FileNotFoundError:
    print(Fore.RED + "Error:" + Fore.WHITE + " The file " +
          Fore.GREEN + "'sample.txt'" + Fore.WHITE + " was not found.")
